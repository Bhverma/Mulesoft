CREATE DATABASE `muledb` ;

CREATE TABLE `department` (
  `employee_id` varchar(10) DEFAULT NULL,
  `designation` varchar(30) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL
);

CREATE TABLE `employee` (
  `employee_id` varchar(10) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL
) ;

USE muledb;
Select * from employee;

Select * from department;